Format des codes:

Le fichier Projet.py est le fichier python qui contient tout les fonctions qui relient le raspberry au capteurs.

Le fichier app.py est le fichier python qui relient le site web et les actions des utilisateurs au site web
et qui également lancent les fonctions du page Projet.py à partir le site web.

Le dossier Template contient les pages HTML et JS.

Le dossier Static contient le page CSS.

***POUR LANCER LA PAGE HTML, VEUILLEZ PARTIR SUR LE DOSSIER TEMPLATE, PUIS LANCER LE FICHIER Projet PAGE PRINCIPALE.html.***